#ifndef COLLISION
#define COLLISION

void dist1(int distance);
void dist2(int distance);
void dist3(int distance);
void dist4(int distance);
void check_dist_func();

#endif